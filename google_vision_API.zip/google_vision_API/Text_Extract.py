# -*- coding: utf-8 -*-
"""
Created on Tue Mar 13 17:37:36 2018

@author: Vidya
"""

from google.cloud.vision import types
import io
import re
import csv

def Text_Extract(Client, File):

    #GET THE CONTENTS OF THE FILE
    with io.open(File, 'rb') as Image_File:
        Content = Image_File.read()
    
    Img = types.Image(content = Content)
    
    #DETECT THE TEXT
    Response = Client.document_text_detection(image = Img)
    Document = Response.full_text_annotation
    print(Document.text)
#    #KEYWORDS LIST       
#    Order_Date = ['date', 'order time', 'order date', 'ordered', 'dipesan', 'pesan', 'tanggal', 'waktu pemesanan']
#    Order_No = ['order #', 'order', 'booking', 'pemesanan']
#    Order_Price = ['rp', 'idr']
#    
#    Date_Flag = False
#    Number_Flag = False
#    
#    #OUTPUT LISTS
#    Output_Order_Date = []
#    Output_Order_No = []
#    Output_Names = []
#    Output_Amount = []
#    
#    #EXTRACT THE REQUIRED DATA
#    Total_Amount = 0
#    for Index, Text in enumerate(Document.text.lower().split('\n')):
#        
#        #ORDER NUMBER   
#        if any(re.search('\\b' + Word + '\\b', Text) for Word in Order_No) and (Number_Flag == False):
#            Number = re.search("\s?[0-9]+[\-\/\s]?[0-9]+", Text)
#            if Number:
#                Output_Order_No.append(Number.group())
#                Number_Flag = True
#            
#        #ORDER DATE
#        if any(re.search('\\b' + Word + '\\b', Text) for Word in Order_Date) and (Date_Flag == False):
#            for Word in Order_Date:
#                if re.search('\\b' + Word + '\\b', Text):
#                    Date_Word = re.search('\\b' + Word + '\\b', Text).group()
#            if Date_Word == Text:
#                Text = Document.text.lower().split('\n')[Index + 1]
#                Text = Text.strip()
#            else:
#                Text = Text.split(Date_Word)
#                Text = Text[1].strip()
#            Date = dateutil.parser.parse(Text, fuzzy_with_tokens = True)
#            Date = str(Date[0]).split()
#            Date = ' '.join(Date)
#            if Date:
#                Output_Order_Date.append(Date)
#                Date_Flag = True
#     
#        #ITEM
#        if any(re.search(Name, Text) for Name in Names):
#            for Name in Names:
#                if (re.search(Name, Text)):
#                    Output_Names.append(Text)
#    
#        #AMOUNT
#        if any(re.search('\\b' + Word + '\\b', Text) for Word in Order_Price):
#            Amount = re.search("\s?[0-9]+(,[0-9]+)*(\.[0-9]+)*\s?", Text)
#            if Amount:
#                Price = re.sub(",","", Amount.group(0))
#                Total_Amount = Total_Amount + float(Price)
#                if (float(Price) > 0):
#                    Output_Amount.append(Price)
#    
#    if Logo_List:                
#        if 'Lazada' in Logo_List:
#            print ('Valid Invoice')
#    elif Entities:  
#        if any(Item in ['Lazada', 'Invoice', 'Lazada Group'] for Item in Entities):
#            print ('Valid Invoice')
#        else:
#            print ('Manual Check Recommended')
#            
#    #WRITE TOCSV
#    Output = [['Order No.', 'Order Date', 'Items', 'Total Amount']] 
#    Temp = []
#    
#    if Output_Order_No:    
#        for Item in Output_Order_No:
#            print ("Order No.: %s" %Item)
#            Temp.append(Item)
#    else:
#            Temp.append('-')   
#            
#    if Output_Order_Date:
#        for Item in Output_Order_Date:
#            print ("Order Date.: %s" %Item)
#            Temp.append(Item)
#    else:
#            Temp.append('-')
#            
#    if Output_Names and Output_Amount:
#        for Item, Price in zip(Output_Names, Output_Amount):
#            print (Item + ": " + Price)
#            Temp.append(Item)
#        
#        #GET THE TOTAL PRICE
#        if len(Output_Names) == 1:
#            Total_Amount = float("{0:.2f}".format(float(Output_Amount[0])))
#            print ("Total: %s" %Output_Amount[0])
#            Temp.append(Output_Amount[0])
#        else:
#            Total_Amount = float("{0:.2f}".format(Total_Amount))
#            print ("Total: %s" %str(Total_Amount))
#            Temp.append(Total_Amount)
#        
#    elif Output_Names and not(Output_Amount):
#        for Item in Output_Names:
#            print (Item)
#        Temp.append(Output_Names)
#        Temp.append('-')
#            
#    else:
#        Temp.append('-')
#        Temp.append('-')
#            
#    if (not Output_Order_No) and (not Output_Order_Date) and (not Output_Names) and (not Output_Amount):
#        print ("Image not clear")
#        
#    Output.append(Temp)
#    File = open('C:\\Users\\Vidya\\Documents\\TechVantage\\Kupukoo\\Output.csv', 'w')  
#    with File:  
#        Writer = csv.writer(File)
#        Writer.writerows(Output)
    
    
    
    
    
    
    
