# -*- coding: utf-8 -*-
"""
Created on Tue Mar 13 17:24:59 2018

@author: Vidya
"""
from google.cloud import vision
import os
import Text_Extract


#SET THE ENVIRONMENT VARABLE AS THE CREDENTIAL KEY
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = 'C:/Users/100119/Desktop/Kupukoo-af2fef3cc770.json'

#INSTANTIATE A CLIENT         
Client = vision.ImageAnnotatorClient()

#GET THE FILE CONTAINING IMAGE
File ='C:/Users/100119/Desktop/6.png'

#EXTRACT THE LOGO FROM THE INVOICE
#Logo_List = Logo_Detect.Logo_Detect(Client, File)

#EXTRACT THE WEB ENTITIES FROM THE INVOICE
#Entities = Web_Entities.Web_Entities(Client, File)

#GET THE MOBILE NAMES
#Mobile_Names = Get_Mobile_Names.Get_Mobile_Names()

#EXTRACT INFORMATION FROM THE TEXT
Text_Extract.Text_Extract(Client, File)
